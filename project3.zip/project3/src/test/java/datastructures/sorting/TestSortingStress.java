package datastructures.sorting;

import misc.BaseTest;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

/**
 * See spec for details on what kinds of tests this class should include.
 */
public class TestSortingStress extends BaseTest {
    @Test(timeout=10*SECOND)
    public void testPlaceholder() {
        // TODO: replace this placeholder with actual code
        assertTrue(true);
    }
}
